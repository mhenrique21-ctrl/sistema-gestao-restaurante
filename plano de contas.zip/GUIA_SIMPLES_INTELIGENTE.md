# 🎯 GUIA PRÁTICO - FLUXO DE CAIXA INTELIGENTE

## O QUE ESSA PLANILHA FAZ (EM 3 SEGUNDOS)

```
VOCÊ INSERE:
└─ Quanto entrou de dinheiro hoje?

SISTEMA MOSTRA AUTOMATICAMENTE:
├─ Qual conta pagar PRIMEIRO
├─ Qual SEGUNDA
├─ Qual TERCEIRA
├─ Quanto SOBRA no final
└─ Se consegue pagar tudo ou não
```

---

## 📊 AS 4 ABAS (MUITO SIMPLES)

### **ABA 1: SIMULADOR DIÁRIO** ← A PRINCIPAL!

```
VOCÊ SÓ PREENCHE 2 COISAS:

1️⃣ QUANTO ENTROU HOJE?
   └─ Célula B3 (em AMARELO)
   └─ Ex: 6500

2️⃣ SALDO ANTERIOR (de ontem)
   └─ Célula B5 (em AMARELO)
   └─ Ex: 2000

SISTEMA CALCULA AUTOMATICAMENTE:

✓ Total disponível: R$ 8.500
✓ Ordem de pagamento das contas
✓ Quanto pagar em cada conta
✓ Quanto sobra no final
✓ Recomendação (pode pagar tudo ou não)
```

---

### **ABA 2: CADASTRO DE CONTAS**

```
PREENCHA UMA ÚNICA VEZ (depois só atualiza):

Para cada conta, insira (em AMARELO):
├─ Nome: "Aluguel"
├─ Valor: 5276
├─ Vencimento: 2024-06-01
└─ Marque como PAGO quando quitar

SISTEMA CALCULA:
├─ Quanto está vencido (VERMELHO)
├─ Quanto vence próximos 7 dias (LARANJA)
└─ Ordena automaticamente por prioridade
```

---

### **ABA 3: HISTÓRICO DIÁRIO**

```
PREENCHA TODOS OS DIAS (2 min):

├─ Coluna A: DATA (vem pronta)
├─ Coluna B: ENTRADA (quanto entrou - em AMARELO)
└─ Coluna C: SALDO ACUMULADO (automático)

Exemplo:
┌─────────┬──────────┬─────────────────┐
│ DATA    │ ENTRADA  │ SALDO ACUMULADO │
├─────────┼──────────┼─────────────────┤
│ 01/06   │ 6.500    │ 6.500           │
│ 02/06   │ 6.500    │ 13.000          │
│ 03/06   │ 6.500    │ 19.500          │
│ 04/06   │ 3.000    │ 22.500          │
└─────────┴──────────┴─────────────────┘
```

---

### **ABA 4: PAINEL VISUAL**

```
MOSTRA EM TEMPO REAL:

├─ Saldo disponível HOJE
├─ Contas vencidas (URGÊNCIA)
├─ Contas a vencer (próximos 7 dias)
└─ Quanto você precisa ter
```

---

## 🚀 COMO USAR (PASSO A PASSO)

### **DIA 1 - CONFIGURAÇÃO INICIAL (15 min)**

**Passo 1: Abra a planilha**
```
Arquivo: FLUXO_CAIXA_INTELIGENTE.xlsx
Vá para: ABA 2 (CADASTRO DE CONTAS)
```

**Passo 2: Insira suas contas**
```
Para CADA conta, preencha (em AMARELO):

Exemplo:
┌──────────────────┬────────┬──────────────┐
│ CONTA            │ VALOR  │ VENCIMENTO   │
├──────────────────┼────────┼──────────────┤
│ Aluguel          │ 5276   │ 2024-06-01   │
│ Folha            │ 19000  │ 2024-06-05   │
│ Energia          │ 4631   │ 2024-06-08   │
│ Plano Saúde      │ 2380   │ 2024-06-10   │
│ Fornecedor       │ 5000   │ 2024-06-15   │
│ Impostos         │ 8000   │ 2024-06-25   │
└──────────────────┴────────┴──────────────┘

(Continue com todas suas contas)
```

**Passo 3: Vá para o SIMULADOR**
```
Vá para: ABA 1 (SIMULADOR DIÁRIO)
Veja se as contas aparecem lá
Pronto! Está tudo configurado!
```

---

### **TODOS OS DIAS (1 min)**

**Momento: Quando receber dinheiro**

```
1. Abra: FLUXO_CAIXA_INTELIGENTE.xlsx
2. Vá para: ABA 1 (SIMULADOR DIÁRIO)
3. Preencha: Célula B3 (ENTRADA DE HOJE)
   └─ Ex: 6500

4. SISTEMA MOSTRA AUTOMATICAMENTE:
   ├─ Célula B6: Saldo disponível
   ├─ Células B13-B17: Ordem de pagamento
   ├─ Célula B18: Total a pagar
   ├─ Célula B20: Quanto sobra
   └─ Célula B23: Recomendação

5. FAÇA OS PAGAMENTOS NA ORDEM
   ├─ Pague primeiro (VENCIDOS)
   ├─ Pague segundo (A VENCER)
   └─ Guarde o resto

6. APÓS PAGAR:
   └─ Vá para ABA 2 e marque CONTAS como "PAGO"
```

---

### **TODA SEMANA (5 min)**

```
SEGUNDA-FEIRA:

1. Abra ABA 2 (CADASTRO DE CONTAS)
2. Revise datas de vencimento
3. Atualize contas que pagou (marque "SIM" em PAGO?)
4. Veja o painel visual (ABA 4)
5. Planeje a semana
```

---

## 💡 EXEMPLO PRÁTICO

### **SEGUNDA-FEIRA DE MANHÃ**

```
VOCÊ INSERE:
├─ B3 (Entrada hoje): 6.500
└─ B5 (Saldo anterior): 2.000

SISTEMA CALCULA E MOSTRA:

B6 (Total disponível): R$ 8.500

ORDEM DE PAGAMENTO AUTOMÁTICA:
├─ 1. Aluguel: R$ 5.276 (VENCIDO há 3 dias) ← PAGUE PRIMEIRO
├─ 2. Folha: R$ 19.000 (VENCIDO há 1 dia) ← MAS NÃO TEM DINHEIRO
├─ 3. Energia: R$ 4.631 (Vence amanhã) ← PAGUE DEPOIS
├─ 4. Plano: R$ 2.380 (Vence em 3 dias) ← SE SOBRAR
└─ 5. Fornecedor: R$ 0 (Vence em 5 dias) ← Ainda não

B18 (Total a pagar): R$ 31.287
B20 (Saldo após pagar): -R$ 22.787 (FALTA!)
B23 (Recomendação): "✗ FALTA DINHEIRO - Pague apenas vencidas"

O QUE VOCÊ FAZ:
1. Paga Aluguel: R$ 5.276 (usando os R$ 8.500)
2. Sobram: R$ 3.224
3. Falta Folha: R$ 19.000 → Negocia com RH
4. Falta Energia: R$ 4.631 → Negocia com CEMIG
```

---

### **QUINTA-FEIRA (SEMANA MAIS POSITIVA)**

```
VOCÊ INSERE:
├─ B3 (Entrada hoje): 6.500
└─ B5 (Saldo anterior): 22.000 (acumulado)

SISTEMA CALCULA E MOSTRA:

B6 (Total disponível): R$ 28.500

ORDEM DE PAGAMENTO:
├─ Aluguel: R$ 0 (já pagou)
├─ Folha: R$ 0 (já pagou)
├─ Energia: R$ 4.631 (Vence hoje)
├─ Plano: R$ 2.380 (Vence em 3 dias)
├─ Fornecedor: R$ 5.000 (Vence em 5 dias)
└─ Impostos: R$ 0 (Vence em 20 dias)

B18 (Total a pagar): R$ 12.011
B20 (Saldo após pagar): R$ 16.489 ✓
B23 (Recomendação): "✓ PODE PAGAR TUDO!"

O QUE VOCÊ FAZ:
1. Paga Energia: R$ 4.631
2. Paga Plano: R$ 2.380
3. Paga Fornecedor: R$ 5.000
4. Sobram: R$ 16.489 (guarde para próximas contas!)
```

---

## 🎨 CORES EXPLICADAS

```
AMARELO = Você preenche aqui
VERMELHO = Contas vencidas (URGÊNCIA!)
LARANJA = Contas a vencer (próximos 7 dias)
VERDE = Sobra (dinheiro que você guardou)
CINZA = Sistema calcula (não mexa)
```

---

## ⚡ FLUXO RÁPIDO DO DIA

```
08:00 - Recebeu dinheiro?
        └─ Insira na ABA 1, célula B3

09:00 - Veja o simulador
        └─ Qual conta pagar PRIMEIRO?

10:00 - Faça a transferência
        └─ Siga a ordem do sistema

14:00 - Marque como pago
        └─ ABA 2, coluna H

18:00 - Revise saldo
        └─ Quanto sobrou?
```

---

## ✅ CHECKLIST DIÁRIO

```
[ ] Abri a planilha?
[ ] Inseri a entrada de hoje (B3)?
[ ] Vi a recomendação do sistema (B23)?
[ ] Fiz os pagamentos recomendados?
[ ] Atualizei contas na ABA 2?
[ ] Guardei documento para amanhã?
```

---

## 🚫 ERROS COMUNS A EVITAR

```
❌ ERRADO: Inserir "R$ 6.500" na célula
✅ CERTO: Inserir "6500" (número puro)

❌ ERRADO: Data como "1 de junho"
✅ CERTO: Data como "2024-06-01" ou "01/06/2024"

❌ ERRADO: Não atualizar contas pagas
✅ CERTO: Marcar "SIM" na coluna PAGO?

❌ ERRADO: Ignorar a recomendação do sistema
✅ CERTO: Seguir a ordem automática

❌ ERRADO: Deixar de preencher entrada diária
✅ CERTO: Preencher TODA ENTRADA que receber
```

---

## 💪 ROTINA IDEAL

### **SEGUNDA-FEIRA (15 min)**
```
1. Abrir planilha
2. ABA 2: Revisar todas as contas
3. ABA 2: Marcar as pagas
4. ABA 1: Ver recomendação geral
5. Planejar semana
```

### **DIARIAMENTE (1-2 min)**
```
1. Recebeu dinheiro? Insira em B3
2. Veja a recomendação (B23)
3. Pague na ordem recomendada
4. Feche a planilha
```

### **SEXTA-FEIRA (10 min)**
```
1. Revisar saldo acumulado
2. Fazer últimos pagamentos
3. Guardar sobra
4. Preparar próxima semana
```

---

## 🎯 O MELHOR DA PLANILHA

```
✓ Você insere ENTRADA
✓ Sistema mostra AUTOMATICAMENTE quanto pagar
✓ Você não precisa calcular nada
✓ Segue a ordem automática (vencidas primeiro)
✓ Vê em tempo real se consegue pagar tudo
✓ Sabe exatamente quanto sobra
✓ 30 dias de histórico
✓ Atualiza tudo em tempo real
```

---

## 🚀 COMEÇANDO AGORA

**HOJE:**
```
1. Baixe: FLUXO_CAIXA_INTELIGENTE.xlsx
2. Abra no Excel/Calc
3. Vá para ABA 2
4. Insira suas contas (nome, valor, vencimento)
5. Tempo: 10 minutos
```

**AMANHÃ:**
```
1. Abra ABA 1 (SIMULADOR)
2. Insira entrada de hoje
3. Veja a recomendação
4. Pague o que conseguir
5. Marca na ABA 2
```

**PRÓXIMAS SEMANAS:**
```
1. Diariamente: Insira entrada
2. Semanalmente: Revise contas
3. Veja seu saldo melhorando!
```

---

## 💬 RESUMO

```
📊 Planilha automática
📈 Simula seu fluxo de caixa
🎯 Prioriza contas por urgência
💰 Mostra quanto sobra
⏰ Atualiza em tempo real
✅ Super prática e simples
```

**Pronto para começar? Abra a planilha e comece HOJE!**

**Qualquer dúvida, releia este guia. Tudo está aqui.**
