# ⚡ CARTÃO RÁPIDO - FLUXO DE CAIXA INTELIGENTE

## 3 PASSOS (1 MINUTO)

```
1️⃣ ABRA: FLUXO_CAIXA_INTELIGENTE.xlsx
   └─ ABA 1 (SIMULADOR DIÁRIO)

2️⃣ INSIRA: Quanto entrou hoje?
   └─ Célula B3 (em AMARELO)

3️⃣ LEIA: Qual conta pagar PRIMEIRO?
   └─ Células B13-B17 (ordem automática)
```

---

## CONFIGURAÇÃO ÚNICA (15 min - SÓ UMA VEZ)

```
1. Vá para: ABA 2 (CADASTRO DE CONTAS)
2. Preencha suas contas:
   ├─ Nome da conta
   ├─ Valor
   └─ Data vencimento (ex: 2024-06-01)
3. Pronto! Sistema ordena automaticamente
```

---

## DIARIAMENTE

```
RECEBEU DINHEIRO?
├─ Insira em B3 (ABA 1)
├─ Veja a ordem de pagamento
├─ Pague na ordem recomendada
└─ Pronto!

APÓS PAGAR?
└─ Marque como "PAGO" na ABA 2
```

---

## CORES DA PLANILHA

```
🟨 AMARELO = Você preenche aqui
🔴 VERMELHO = Contas vencidas (URGÊNCIA!)
🟠 LARANJA = Contas a vencer (próximos 7 dias)
🟢 VERDE = Sobra (dinheiro guardado)
```

---

## EXEMPLO

```
VOCÊ INSERE:
├─ Entrada hoje: R$ 6.500
└─ Saldo anterior: R$ 2.000

SISTEMA MOSTRA:
├─ Total: R$ 8.500
├─ Pagar Aluguel PRIMEIRO: R$ 5.276
├─ Pagar Energia DEPOIS: R$ 4.631
└─ Sobra: -R$ 1.407 (falta dinheiro)

RECOMENDAÇÃO: "Pague só as vencidas, negocie as outras"
```

---

## CHECKLIST DIÁRIO (Marque aqui)

```
[ ] Inseri a entrada de hoje?
[ ] Vi o que pagar PRIMEIRO?
[ ] Fiz a transferência?
[ ] Atualizei contas na ABA 2?
[ ] Guardei o documento?

TODO DIA!
```

---

## 🚀 COMEÇAR AGORA

**DIA 1 (15 min):**
1. Abra ABA 2
2. Insira suas contas
3. Pronto!

**DIA 2 (1 min):**
1. Abra ABA 1
2. Insira entrada
3. Veja o que pagar
4. Pague!

**CADA DIA (1 min):**
1. Entrada de hoje
2. Sistema mostra ordem
3. Você paga

---

## 📞 SE TIVER DÚVIDA

Releia: GUIA_SIMPLES_INTELIGENTE.md

---

**COLA NA PAREDE DO ESCRITÓRIO!**
**USE TODOS OS DIAS!**
**SEU CAIXA VAI MELHORAR!**
